module.exports.USERS_TABLE = process.env.USERS_TABLE;
module.exports.IS_OFFLINE = process.env.IS_OFFLINE;